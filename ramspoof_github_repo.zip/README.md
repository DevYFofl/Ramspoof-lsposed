# RAMSpoof LSPosed Module - GitHub Actions Build

This repository contains an Android project (LSPosed/Xposed module) that spoofs RAM values
for `ru.andr7e.deviceinfohw`. It is prepared to be built with GitHub Actions (no local PC needed).

## How to use (from mobile-only):
1. Create a new public repository on GitHub (you can use the web interface on mobile).
2. Upload the contents of this folder (all files) to the repository (you can use GitHub web or the 'Upload files' button).
3. On GitHub, go to Actions → select the `Build APK` workflow and run it (or push to `main` branch).
4. After the workflow completes, go to the workflow run and download the artifact named `app-apk` (contains `app-debug.apk`).
5. Install the APK on your device, enable the module in LSPosed Manager, restrict to target app `ru.andr7e.deviceinfohw`, and reboot.

Notes:
- The build may fail if Gradle or Android tooling versions change. If so tell me the error and I will adjust the workflow.
- You might need to add an Xposed API jar or adjust dependencies if the build fails; I can provide guidance/updated files.
