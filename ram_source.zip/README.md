Ram Spoofer by DevYF - Gradle-ready project

Place xposed_api.jar into app/libs/ before building on GitHub.
