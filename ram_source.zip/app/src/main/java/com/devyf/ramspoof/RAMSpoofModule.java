package com.devyf.ramspoof;
import android.app.ActivityManager;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
public class RAMSpoofModule implements IXposedHookLoadPackage {
    private static final String TARGET_PKG = "ru.andr7e.deviceinfohw";
    private static final long SPOOF_TOTAL_BYTES = 8192L * 1024L * 1024L;
    private static final long SPOOF_AVAILABLE_BYTES = (long)(SPOOF_TOTAL_BYTES * 0.7);
    @Override public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        if (!lpparam.packageName.equals(TARGET_PKG)) return;
        try {
            XposedHelpers.findAndHookMethod("android.app.ActivityManager", lpparam.classLoader, "getMemoryInfo", ActivityManager.MemoryInfo.class, new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    Object outObj = param.args[0];
                    if (outObj instanceof ActivityManager.MemoryInfo) {
                        ActivityManager.MemoryInfo info = (ActivityManager.MemoryInfo) outObj;
                        try { info.totalMem = SPOOF_TOTAL_BYTES; } catch (Throwable t) {}
                        try { info.availMem = SPOOF_AVAILABLE_BYTES; } catch (Throwable t) {}
                        try { info.lowMemory = false; } catch (Throwable t) {}
                    }
                }
            });
        } catch (Throwable t) {}
        try { XposedHelpers.findAndHookMethod("java.lang.Runtime", lpparam.classLoader, "maxMemory", new XC_MethodHook() {
            @Override protected void afterHookedMethod(MethodHookParam param) throws Throwable { param.setResult(SPOOF_TOTAL_BYTES / 2); }
        }); } catch (Throwable t) {}
        try { XposedHelpers.findAndHookMethod("java.lang.Runtime", lpparam.classLoader, "totalMemory", new XC_MethodHook() {
            @Override protected void afterHookedMethod(MethodHookParam param) throws Throwable { param.setResult(SPOOF_TOTAL_BYTES / 3); }
        }); } catch (Throwable t) {}
        try { XposedHelpers.findAndHookMethod("android.os.SystemProperties", lpparam.classLoader, "get", String.class, new XC_MethodHook() {
            @Override protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                String key = (String) param.args[0];
                if (key != null && (key.contains("ro.product.model") || key.contains("ro.product.manufacturer"))) {
                    param.setResult("Pixel 6 Pro");
                }
            }
        }); } catch (Throwable t) {}
    }
}
