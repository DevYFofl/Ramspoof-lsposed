package com.devyf.ramspoof;

import android.app.ActivityManager;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class RAMSpoofModule implements IXposedHookLoadPackage {

    // قائمة الحزم المستهدفة
    private static final String[] TARGET_PKGS = {
        "com.epicgames.fortnite",
        // أضف هنا أي حزم أخرى تريد تعديلها
    };

    // القيم الجديدة للرام
    private static final long SPOOF_TOTAL_BYTES = 16L * 1024L * 1024L * 1024L; // 16 جيجابايت
    private static final long SPOOF_AVAILABLE_BYTES = (long)(SPOOF_TOTAL_BYTES * 0.7); // 70% متاحة

    // اسم الـ GPU المزيف
    private static final String FAKE_GPU_NAME = "Adreno 660"; // يدعم Fortnite

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        boolean isTargetPackage = false;
        for (String pkg : TARGET_PKGS) {
            if (lpparam.packageName.equals(pkg)) {
                isTargetPackage = true;
                break;
            }
        }
        if (!isTargetPackage) return;

        try {
            // تعديل معلومات الذاكرة
            XposedHelpers.findAndHookMethod("android.app.ActivityManager", lpparam.classLoader, "getMemoryInfo", ActivityManager.MemoryInfo.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    Object outObj = param.args[0];
                    if (outObj instanceof ActivityManager.MemoryInfo) {
                        ActivityManager.MemoryInfo info = (ActivityManager.MemoryInfo) outObj;
                        try {
                            info.totalMem = SPOOF_TOTAL_BYTES;
                        } catch (Throwable t) {}
                        try {
                            info.availMem = SPOOF_AVAILABLE_BYTES;
                        } catch (Throwable t) {}
                        try {
                            info.lowMemory = false;
                        } catch (Throwable t) {}
                    }
                }
            });

            // تعديل استعلام الـ GPU
            XposedHelpers.findAndHookMethod("android.os.Build", lpparam.classLoader, "getRadioVersion", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    // لا شيء هنا، فقط مثال على تعديل اسم GPU
                }
            });

            // تغيير اسم الـ GPU - كود مخصص يعتمد على طريقة استدعاء اسم الـ GPU
            XposedHelpers.findAndHookMethod("android.os.SystemProperties", lpparam.classLoader, "get", String.class, String.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    String key = (String) param.args[0];
                    if (key.equals("ro.hardware") || key.equals("ro.product.model")) {
                        param.setResult(FAKE_GPU_NAME);
                    }
                }
            });

            // محاولة دعم أكثر من RAM واحد (غير مضمون بشكل كامل، يعتمد على التطبيق)
            // هنا يمكنك إضافة تغييرات إضافية حسب الحاجة

        } catch (Throwable t) {
            // سجل أي خطأ
        }
    }
}