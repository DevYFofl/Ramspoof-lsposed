package com.devyf.ramspoof;

import android.app.ActivityManager;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class RAMSpoofModule implements IXposedHookLoadPackage {

    private static final String TARGET_PKG = "com.epicgames.fortnite";

    // قيمة الرام الجديدة
    private static final long NEW_TOTAL_RAM_BYTES = 8L * 1024L * 1024L * 1024L; // 8 جيجابايت

    // معلومات الـ GPU
    private static final String GPU_NAME = "Adreno (Supported for Fortnite)";

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        if (!lpparam.packageName.equals(TARGET_PKG)) return;

        try {
            // تعديل الذاكرة
            XposedHelpers.findAndHookMethod(
                "android.app.ActivityManager",
                lpparam.classLoader,
                "getMemoryInfo",
                ActivityManager.MemoryInfo.class,
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                        Object outObj = param.args[0];
                        if (outObj instanceof ActivityManager.MemoryInfo) {
                            ActivityManager.MemoryInfo info = (ActivityManager.MemoryInfo) outObj;
                            try {
                                info.totalMem = NEW_TOTAL_RAM_BYTES;
                            } catch (Throwable t) {
                                // يمكن وضع سجل هنا لو أردت
                            }
                            try {
                                info.availMem = (long) (NEW_TOTAL_RAM_BYTES * 0.7);
                            } catch (Throwable t) {
                                // سجل الخطأ
                            }
                            try {
                                info.lowMemory = false;
                            } catch (Throwable t) {
                                // سجل الخطأ
                            }
                        }
                    }
                }
            );

            // تغيير معلومات الـ GPU
            XposedHelpers.findAndHookMethod(
                "android.os.Build",
                lpparam.classLoader,
                "getRadioVersion",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                        param.setResult(GPU_NAME);
                    }
                }
            );

            // تعديل خصائص build.prop بشكل برمجي
            XposedHelpers.findAndHookMethod(
                "android.os.SystemProperties",
                lpparam.classLoader,
                "get",
                String.class,
                String.class,
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                        String key = (String) param.args[0];
                        if (key.equals("ro.hardware")) {
                            param.setResult("sdm845"); // مثال، يمكن تغييره
                        } else if (key.equals("ro.product.model")) {
                            param.setResult("MyDevice 8GB");
                        } else if (key.equals("ro.memory_size")) {
                            param.setResult("8G");
                        }
                    }
                }
            );
        } catch (Throwable t) {
            // يمكنك تسجيل الخطأ هنا لو أردت
        }
    }
}