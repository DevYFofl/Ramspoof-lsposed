package com.devyf.ramspoof;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Button applyBtn, resetBtn, infoBtn;
    TextView statusTxt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        applyBtn = findViewById(R.id.btn_apply);
        resetBtn = findViewById(R.id.btn_reset);
        infoBtn = findViewById(R.id.btn_info);
        statusTxt = findViewById(R.id.txt_status);

        applyBtn.setOnClickListener(v -> {
            Toast.makeText(this, "Applying RAM spoof (enable module in LSPosed)", Toast.LENGTH_LONG).show();
            statusTxt.setText("Spoof applied: 8192 MiB (LPDDR5)"); 
        });

        resetBtn.setOnClickListener(v -> {
            Toast.makeText(this, "Reset to device defaults (requires reboot)", Toast.LENGTH_LONG).show();
            statusTxt.setText("Spoof cleared"); 
        });

        infoBtn.setOnClickListener(v -> {
            Toast.makeText(this, "Ram Spoofer by DevYF\nTarget: ru.andr7e.deviceinfohw", Toast.LENGTH_LONG).show();
        });
    }
}
