package com.devyf.ramspoof;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button apply = findViewById(R.id.btnApply);
        Button reset = findViewById(R.id.btnReset);
        Button info = findViewById(R.id.btnInfo);

        apply.setOnClickListener(v -> Toast.makeText(this, "RAM spoof applied!", Toast.LENGTH_SHORT).show());
        reset.setOnClickListener(v -> Toast.makeText(this, "Reset done!", Toast.LENGTH_SHORT).show());
        info.setOnClickListener(v -> Toast.makeText(this, "Ram Spoofer by DevYF", Toast.LENGTH_SHORT).show());
    }
}
