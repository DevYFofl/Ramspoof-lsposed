package com.devyf.ramspoof;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button applyBtn, resetBtn, infoBtn;
    TextView statusTxt;
    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        setContentView(R.layout.activity_main);
        applyBtn = findViewById(R.id.btn_apply);
        resetBtn = findViewById(R.id.btn_reset);
        infoBtn = findViewById(R.id.btn_info);
        statusTxt = findViewById(R.id.txt_status);
        applyBtn.setOnClickListener(v -> { Toast.makeText(this, "Apply Spoof: 8192 MiB (LPDDR5)", Toast.LENGTH_SHORT).show(); statusTxt.setText("Spoof applied: 8192 MiB (LPDDR5)"); });
        resetBtn.setOnClickListener(v -> { Toast.makeText(this, "Reset to defaults (reboot may be required)", Toast.LENGTH_SHORT).show(); statusTxt.setText("Spoof cleared"); });
        infoBtn.setOnClickListener(v -> Toast.makeText(this, "Ram Spoofer by DevYF - Targets: ru.andr7e.deviceinfohw", Toast.LENGTH_LONG).show());
    }
}
